
public class Hello {

    /*public static void Main(String[] args) {
        System.out.println("Hello...");
    }*/

    public static void main(String []arr) {
        //String []arr=new String[]{"abc","new","mew"};
        //Main(arr);
        System.out.println("print");
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
    }
}
