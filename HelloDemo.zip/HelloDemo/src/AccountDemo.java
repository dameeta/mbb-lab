class SavingAccount{

     private double initBalance;
   public static int accNo;


   public void saving()
   {
       System.out.println(accNo);
       System.out.println(initBalance);
   }
}

public class AccountDemo {
    public static void PrintDetails()
    {
       // SavingAccount savingAccount=new SavingAccount();
        SavingAccount.accNo=1200189;
        System.out.println();
    }
}
