package org.management.users.simpledemo;

public class Aeroplane  implements flyingVehicle,flyingObject{


    @Override
    public void fly() {
        System.out.println("Aeroplane can fly with help iof its engine..");
    }

    @Override
    public void wings() {
        System.out.println("Aeroplane has wings to fly...");
    }


}
