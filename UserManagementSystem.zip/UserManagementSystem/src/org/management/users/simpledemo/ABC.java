package org.management.users.simpledemo;

public class ABC implements A{


    @Override
    public void Add() {
        System.out.println("inside ABC");
    }
}
