package org.management.users.simpledemo;

public class AB implements A{
    @Override
    public void Add() {
        System.out.println("inside AB");
    }
}
