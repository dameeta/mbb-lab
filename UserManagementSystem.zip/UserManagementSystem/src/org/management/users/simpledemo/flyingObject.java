package org.management.users.simpledemo;

public interface flyingObject {

    public void fly();
}
