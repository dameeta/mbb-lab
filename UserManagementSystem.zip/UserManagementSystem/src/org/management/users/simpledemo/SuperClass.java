package org.management.users.simpledemo;

public class SuperClass {
    public SuperClass()
    {
        System.out.println("Inside SuperClass Constructor");
    }
    public void superClassMethod()
    {
        System.out.println("Inside superClassMethod()");
    }
}
class nextSuper extends SuperClass{
    public nextSuper()
    {
        System.out.println("inside nextSuper Constructor");
    }
    public void superClassMethod()
    {

        System.out.println("Inside nextSuper class method");
        super.superClassMethod();
    }
}
class nexttonextSuper extends  nextSuper{

    public nexttonextSuper()
    {
        System.out.println("inside nexttonextSuper Constructor..");
    }

    @Override
    public void superClassMethod() {
        superClassMethod();
    }
}
class subClass extends nexttonextSuper{
    public subClass()
    {
        System.out.println("inside subClass constructor..");
    }

    @Override
    public void superClassMethod() {
        superClassMethod();
    }

    public static void main(String[] args) {
        subClass subClass=new subClass();
        subClass.superClassMethod();
    }
}
