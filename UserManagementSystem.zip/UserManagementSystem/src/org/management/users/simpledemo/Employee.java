package org.management.users.simpledemo;

public class Employee {

    String empname="Sudhir";
    int empId=567;
    String desg="Analyst";
    public Employee()
    {
        System.out.println("default constructor..");
    }

    public Employee(String empname) {
        this.empname = empname;
    }

    public Employee(int empId) {
        this.empId = empId;
    }

    public Employee(String empname, int empId, String desg) {
        this.empname = empname;
        this.empId = empId;
        this.desg = desg;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empname='" + empname + '\'' +
                '}';
    }

    public static void main(String[] args) {
        Employee employee1=new Employee();
        Employee employee2=new Employee("Anita");
        Employee employee3=new Employee("Suresh");
        Employee employee4=new Employee("Umesh");
        Employee employee5=new Employee("Neeta");
        Employee employee6=new Employee("Usha");
        System.out.println(employee2 +" " +employee5 );

    }
}
