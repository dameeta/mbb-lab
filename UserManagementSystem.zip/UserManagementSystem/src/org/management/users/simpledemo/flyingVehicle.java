package org.management.users.simpledemo;

public interface flyingVehicle {

    public void wings();

}
