package org.management.users.simpledemo;

public interface A {
    public void Add();
}
