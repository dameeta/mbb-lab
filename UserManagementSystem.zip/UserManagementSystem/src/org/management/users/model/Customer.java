package org.management.users.model;

import org.management.users.loginrepo.dashboard;
import org.management.users.loginrepo.loginSystem;

public class Customer extends User implements loginSystem, dashboard {
    public String userName;
    public String password;
    public Customer(String userName,String password)
    {
        super();
        this.userName=userName;
        this.password=password;
    }

    public Customer() {

    }

    @Override
    public void displayDashboard() {

    }

    @Override
    public void resetPassword() {

    }

    @Override
    public void loginValidation() {

    }
}
