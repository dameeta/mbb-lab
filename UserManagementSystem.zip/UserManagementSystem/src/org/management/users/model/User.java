package org.management.users.model;

import org.management.users.modelsub.Admin;
import org.management.users.modelsub.GuestUser;

public abstract class User {

    private String userName;
    private String password;
    User [] userList;
public User()
{

}
public User(Admin admin, Customer customer, GuestUser guestUser)
{

}
public User(String uname,String pwd)
{
    this.userName=uname;
    this.password=pwd;
}
    public  abstract void resetPassword();

}
