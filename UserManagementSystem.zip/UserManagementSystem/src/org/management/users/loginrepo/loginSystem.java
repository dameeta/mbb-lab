package org.management.users.loginrepo;

public interface loginSystem {

    public void loginValidation();
}
