package org.management.users.loginrepo;

import java.util.Scanner;

public interface dashboard {

    public void displayDashboard();
    Scanner sc=new Scanner(System.in);
}
