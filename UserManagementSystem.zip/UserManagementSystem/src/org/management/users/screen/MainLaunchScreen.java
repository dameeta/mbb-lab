package org.management.users.screen;

import org.management.users.model.Customer;
import org.management.users.model.User;
import org.management.users.modelsub.Admin;
import org.management.users.modelsub.GuestUser;

public class MainLaunchScreen {


    public void showUsers()
    {
        //User userList[]=new User[];
        //userList[0]=new User(new Admin(),new Customer(),new GuestUser());

    }
    public static void main(String[] args) {
        Admin adminobj=new Admin();
        adminobj.displayDashboard();
    }
}
