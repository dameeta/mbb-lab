package org.management.users.modelsub;

import org.management.users.model.User;

public class GuestUser extends User {
    protected String username;
    public String password;

    public GuestUser()
    {

    }
    @Override
    public void resetPassword() {

    }
}
