package org.management.users.modelsub;

import org.management.users.loginrepo.dashboard;
import org.management.users.model.User;

import java.util.Scanner;

public class Admin extends User implements dashboard {
    String adminName=" Swami ";
    String password;
    @Override


    public void resetPassword() {

    }

    @Override
    public void displayDashboard() {
        System.out.println("Welcome "+ adminName + "your page.." );
        System.out.println("Enter the below choice");
        System.out.println("1. Reset Password");
        System.out.println("2.View Users");
        System.out.println("3.Remove Users");
        System.out.println("4. Logout");
        Scanner scanner=new Scanner(System.in);
        int choice=scanner.nextInt();
        switch (choice){
            case 1: resetPassword();
            break;
            case 2:  viewUser();
            break;
            case 3: removeUsers();
            case 4: System.exit(0);
            break;
        }
    }

    private void removeUsers() {


    }

    private void viewUser() {
    }
}
